
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sam
 */
public class sam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the no. of elements");
        int n=s.nextInt();
        int b[]=new int[n];
        int ex,ch;
                System.out.println("Enter the elements");

        for(int i=0;i<n;i++)
        {
              b[i]=s.nextInt();
        }   
          ex=b[0];
          ch=b[1];
        for(int i=1;i<n;i++)
        {
              if(b[i]>ex)
              {   
                   ex=b[i];
        }
             else
              {
                   if(b[i]<ch)
                   {
                   ch=b[i];
                   }
             }
             // System.out.println("Cheapest:")
    }
                      System.out.println("Expensive:"+ex);
              System.out.println("Cheapest:"+ch);

    }
}
