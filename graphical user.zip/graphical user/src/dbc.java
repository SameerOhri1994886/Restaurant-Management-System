/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sam
 */
import java.sql.*;

public class dbc {

    
    public static void main(String[] args)throws SQLException {
   Connection con=null;
   //String dbName="sameer";
   //String serverport="3307";
   //String driver="mysql-connector-java-8.0.15";
    Statement st=null;
    ResultSet rs=null;
        try
        {
     //ResultSetMetaData rd;
   Class.forName("com.mysql.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3307/sameer","root","");
    st=con.createStatement();
    rs=st.executeQuery("select * from menu");
    //rd=rs.getMetaData();
    while(rs.next())
    {
    System.out.println(rs.getString("ITEMS")+", "+ rs.getString("PRICE"));
    
       
    }}
      //st.close();
      //rs.close();
      //con.close();
       
    
    
        
        catch(Exception ex)
        {
            ex.printStackTrace();
        }finally{
            if(rs!=null)
            {
                rs.close();
            }
             if(st!=null)
             {
                 st.close();
            }
        }
    }
    
}
